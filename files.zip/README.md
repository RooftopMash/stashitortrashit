# Stash or Trash???

A WebApp for users to rate, review, and share opinions with a fun "Stash or Trash" toggle system.

## Features
- 🔥 Trending Reviews
- 💰 "Stash It" or 🗑️ "Trash It" toggle
- 📝 Add review text with emoji/mood support
- 📷 Upload images/videos

## Project Structure
```
stashitortrashit/
├── backend/               # Backend folder (Node.js API)
├── frontend/              # Frontend folder (React.js app)
└── README.md              # Project documentation
```

## Installation
1. Clone the repository:
   ```bash
   git clone https://github.com/RooftopMash/stashitortrashit.git
   ```

2. Install dependencies for the backend and frontend:
   ```bash
   cd backend && npm install
   cd ../frontend && npm install
   ```

3. Run the backend:
   ```bash
   cd backend && npm start
   ```

4. Run the frontend:
   ```bash
   cd frontend && npm start
   ```

## Deployment
- Backend: Deploy on platforms like **Heroku** or **Railway**.
- Frontend: Deploy on **Vercel**.