const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Placeholder route
app.get('/', (req, res) => {
  res.send('Welcome to Stash or Trash API!');
});

// Reviews route
app.get('/reviews', (req, res) => {
  const sampleReviews = [
    { id: 1, title: "Best Headphones", stashed: 212, trashed: 87 },
    { id: 2, title: "Worst Coffee Shop", stashed: 12, trashed: 320 },
  ];
  res.json(sampleReviews);
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));