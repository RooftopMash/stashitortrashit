import React from 'react';

function App() {
  return (
    <div>
      <header>
        <h1>Stash or Trash???</h1>
        <button>Rate Something ➕</button>
      </header>
      <main>
        <h2>🔥 Trending Reviews</h2>
        <div className="review-card">
          <h3>Best Headphones</h3>
          <p>💰 212 | 🗑️ 87</p>
        </div>
        <div className="review-card">
          <h3>Worst Coffee Shop</h3>
          <p>💰 12 | 🗑️ 320</p>
        </div>
      </main>
    </div>
  );
}

export default App;